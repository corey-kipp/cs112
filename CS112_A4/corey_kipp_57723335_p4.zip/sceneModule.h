#ifndef SCENEMODULE_H
#define SCENEMODULE_H

#include <GL/glut.h>

void drawScene();
void display();

#endif // SCENEMODULE_H
